#ifndef _IPC_WIN_CMD_DEF_H_
#define _IPC_WIN_CMD_DEF_H_
//
#define IPC_MSG_BASE WM_USER+1000

#define    IPC_MSG_SOLUTION                    ( IPC_MSG_BASE + 0 )

#define    IPC_MSG_VIDEOWNDMOVE                ( IPC_MSG_BASE + 1 )

#define    IPC_MSG_LOGSAVING                ( IPC_MSG_BASE + 2 )

#endif//_IPC_WIN_CMD_DEF_H_
