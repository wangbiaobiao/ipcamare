//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IPCFilePlayDemo.rc
//
#define IDD_IPCFILEPLAYDEMO_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDR_MENU_FILE                   129
#define IDD_DIALOG1                     130
#define IDD_DIALOG_REGION               130
#define IDD_DLG_CUT                     131
#define IDC_BUTTON_PLAY                 1001
#define IDC_BUTTON_STOP                 1002
#define IDC_BUTTON_PAUSE                1003
#define IDC_BUTTON_PREV                 1004
#define IDC_BUTTON_NEXT                 1005
#define IDC_COMBO1                      1006
#define IDC_SLIDER1                     1007
#define IDC_SLIDER2                     1012
#define IDC_SLIDER_VOLUME               1012
#define IDC_BTN_CAPTURE                 1014
#define IDC_STATIC_STATE                1015
#define IDC_STATIC_W                    1016
#define IDC_STATIC_H                    1017
#define IDC_STATIC_TOTALFRAME           1018
#define IDC_BTN_SETPOS                  1019
#define IDC_STATIC_FPOS                 1020
#define IDC_EDIT1                       1021
#define IDC_BTN_CAPTURETOBUFF           1021
#define IDC_EDIT_START                  1021
#define IDC_BTN_REPLAY                  1022
#define IDC_EDIT_END                    1022
#define IDC_EDIT_FPOS                   1023
#define IDC_EDIT_LEFT                   1024
#define IDC_EDIT_TOP                    1025
#define IDC_EDIT_LEFT2                  1026
#define IDC_EDIT_TOP2                   1027
#define IDC_BTN_GETRECT                 1028
#define IDC_BTN_SETRECT                 1029
#define IDC_BTN_FORWARD                 1030
#define IDC_BTN_BACKWARD                1031
#define IDC_EDIT_BACKWARD               1032
#define IDC_EDIT_FOEWARD                1033
#define IDC_EDIT_FORWARD                1033
#define IDC_BTN_REPLAY2                 1034
#define IDC_BTN_CUT                     1034
#define IDC_CHECK1                      1035
#define IDC_CHECK_MUTE                  1035
#define IDC_BUTTON1                     1036
#define IDC_BUTTON_RANGZOOM             1036
#define IDC_EDIT3                       1037
#define IDC_STATIC_TOTALTIME            1037
#define IDC_STATIC_MAX                  1038
#define ID_FILE_OPEN32771               32771
#define ID_FILE_CLOSE32772              32772
#define ID_Menu                         32773
#define ID_FILE_CLOSE32774              32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
